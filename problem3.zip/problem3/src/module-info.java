/**
 * 
 */
/**
 * @author user
 *
 */
module problem3 {
}