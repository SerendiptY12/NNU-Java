import java.util.Scanner;

public class Problem8 {
    public static void main(String[] args) {
        System.out.print("请输入两个整数值:");
        Scanner in=new Scanner(System.in);
        int a=in.nextInt(),n=in.nextInt(),sum=0;
        int aa=a;
        for (int i = 0; i < n; i++) {
            sum+=a;
            a=a*10+aa;
        }
        System.out.println("和="+sum);
    }
}
