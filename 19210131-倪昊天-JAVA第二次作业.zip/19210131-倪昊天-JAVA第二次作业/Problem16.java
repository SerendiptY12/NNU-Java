import java.util.Scanner;

public class Problem16 {
    public static boolean isPrime(int n)
    {
        if(n<=2)
        {
            return false;
        }
        for(int i=2;i*i<=n;i++)
        {
            if(n%i==0)
                return false;
        }
        return true;
    }
    public static void print(int n)
    {
        System.out.print("最接近" + n + "的素数是：");
        int x=1;
        if (isPrime(n)) {
                System.out.print(n);
                return;
        } else
            {
                while(true) {
                    if (isPrime(n - x) && isPrime(n + x)) {
                        System.out.print(n - x + " 和 " + (n + x));
                        return;
                    }
                    else if (isPrime(n - x) && !isPrime(n + x)) {
                        System.out.print(n - x);
                        return;
                    }
                    else if (!isPrime(n - x) && isPrime(n + x)) {
                        System.out.print(n + x);
                        return;
                    }
                    else
                        x++;
                }
            }
    }

    public static void main(String[] args) {
        System.out.print("请输入一个正整数：");
        int n=0;
        Scanner in=new Scanner(System.in);
        n=in.nextInt();
        print(n);
    }
}
