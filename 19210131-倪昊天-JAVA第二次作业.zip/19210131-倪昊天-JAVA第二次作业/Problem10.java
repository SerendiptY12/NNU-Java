import java.util.Scanner;

public class Problem10 {
    public static void Print(int n)
    {
        int b =0;
        switch (n/10)
        {
            case 6:
                b =2;
                break;
            case 7:
                b =3;
                break;
            case 8:
                b =4;
                break;
            case 9:
            case 10:
                b =5;
                break;
            default:
                b =1;
                break;
        }
        for (int i = 0; i < b; i++) {
            System.out.print("*");
        }
    }
    public static void main(String[] args) {
        Scanner in=new Scanner(System.in);
        System.out.print("请输入一个正整数值：");
        int n=in.nextInt();
        Print(n);
    }
}
