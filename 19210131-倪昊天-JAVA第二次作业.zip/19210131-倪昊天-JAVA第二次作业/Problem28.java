import java.util.Scanner;

/*
第1题 ：使用递归实现如下的方法：
s(n)=s(n-1)+n  当n>0时
s(0)=0        当n=0时
程序设计要求：
1）设计实现递归方法，完成s(n)的功能。
2）在public  static void main(String[] args)方法中，通过Scanner类读入一个整数值，如：100，然后通过调用1)定义的递归方法，向这个方法传入刚读入的那个值进去，按指定格式在屏幕上输出结果。
输入：
请输入一个正整数： 100
输出：
和=5050
 */
public class Problem28 {
    public static int getValue(int n)
    {
        if (n==0)
            return 0;
        else
            return getValue(n-1)+n;
    }
    public static void main(String[] args) {
        System.out.print("请输入一个正整数：");
        Scanner in=new Scanner(System.in);
        int num=in.nextInt();
        System.out.println(getValue(num));
    }

}
