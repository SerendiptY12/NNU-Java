import java.util.Scanner;

public class Problem2 {
    public static void print(int i,int j,int k)
    {
        int count=0;
        for (int l = i; l <= j ; l++) {
            count++;
            System.out.print(l+" ");
            if (count>=k) {
                System.out.println();
                count=0;
            }
        }
    }
    public static void main(String[] args)
    {
        Scanner in= new Scanner(System.in);
        int i,j,k;
        i=in.nextInt();
        j=in.nextInt();
        k=in.nextInt();
        print(i,j,k);
    }
}
