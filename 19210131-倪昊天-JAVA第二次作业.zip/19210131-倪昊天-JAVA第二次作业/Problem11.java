import java.util.Scanner;

public class Problem11 {
    public static int GetValue(int a[]) {
        int length=a.length;
        a[0]=1;
        int ans=0;
        for(int i=1;i<length;i++)
        {
            a[i]=a[i-1]*(2*i)*(2*i+1);
        }
        for(int i=0;i<length;i++)
            ans+=a[i];
        return ans;
    }
    public static void main(String[] args) {
        Scanner in=new Scanner(System.in);
        System.out.print("请输入一个正整数值：");
        int n=in.nextInt();
        int a[]=new int[(n+1)/2];
        System.out.println(GetValue(a));
    }

}
