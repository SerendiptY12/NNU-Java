import java.util.Scanner;

/**
 * 第4题   n只蚂蚁以每秒1cm的速度在长度为Lcm的竿子上爬行。当蚂蚁爬行到竿子的端点时就会掉落。由于竿子太细，两只蚂蚁相遇时，它们不能交错通过，只能各自反向爬回去。对于每只蚂蚁，我们知道它距离竿子左端的距离xi，但不知道它的朝向。请计算所有的蚂蚁落下竿子的最短时间和最长时间 。
 * 要求：
 * 竿子长度L：1<=L<=1000000
 * 蚂蚁数量n：1<=n<=1000000
 * 每只蚂蚁距左端的距离xi: 0<=xi<=L
 * 输入界面：
 * 请输入竿子长度L值：10
 * 请输入蚂蚁数量n值：3
 * 请输入每只蚂蚁的距离： 2   6   7
 * 输出界面：
 * 最短时间：4  朝向：左 、右、右
 * 最长时间：8  朝向：右 、右、右
 */
 public class Problem39 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("请输入竿子长度L值：");
        int L=in.nextInt();
        System.out.print("请输入蚂蚁数量n值：");
        int n=in.nextInt();
        System.out.print("请输入每只蚂蚁的距离：");
        int a[]=new int[n];
        for(int i=0;i<n;i++)
            a[i]=in.nextInt();
        int max=a[0];
        for(int i=0;i<n;i++)
        {
            int smaller=a[i]<(L-a[i])?a[i]:(L-a[i]);
            max=smaller>max?smaller:max;
        }
        System.out.print("最短时间："+max+" 朝向:");
        for(int i=0;i<n;i++)
            if(L-a[i]<=max)
                System.out.print(" 右");
            else
                System.out.print(" 左");
        int imax=0;
        for(int i=0;i<n;i++)
        {
            int larger=a[i]>(L-a[i])?a[i]:(L-a[i]);
            if(larger>max)
            {
                max=larger;
                imax=i;
            }
        }
        System.out.println("");
        System.out.print("最长时间："+max+" 朝向:");
        L1:for(int i=0;i<n;i++)
        {
            if(i==imax)
                if(a[imax]>L-a[imax])
                {
                    System.out.print(" 左");
                    continue L1;
                }
            System.out.print(" 右");
        }
    }

}
