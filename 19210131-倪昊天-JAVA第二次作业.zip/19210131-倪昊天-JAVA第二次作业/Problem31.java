import java.util.Scanner;

/*
第4题 ：使用递归实现如下的功能：
从键盘上读入一个非负整数，屏幕上输出这上整数的倒序的十进制数。
如：键盘上输入2456,则屏幕输出6542
程序设计要求：
1）设计一个递归方法，完成：对给定的参数n(如:调用时传给n的值是2465),在该方法内部，通过递归的方式，计算并返回该参数的倒序所对应的整数值（注意：不是在屏幕上打印，而是计算出倒序的值并返回出来）。
算法提示：对于2456，其进行递归方式的计算过程如下：
(2456 ,0) (245,6)(24,65)(2,654)(0,6542)6542


2）在public  static void main(String[] args)方法中，通过Scanner类读入一个整数值，如：2456  ，然后通过调用1)定义的递归方法，向这个方法传入刚读入的值进去，将该方法的返回值，在屏幕上按指定的格式输出。
输入：
请输入一个正整数： 12456
输出：
12456的倒序是：65421


 */
public class Problem31 {
    public static int getVerse(int m,int n)
    {
        if(m==0)
            return n;
        return getVerse(m/10,n*10+m%10);
    }
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        System.out.println(getVerse(n,0));
    }
}
