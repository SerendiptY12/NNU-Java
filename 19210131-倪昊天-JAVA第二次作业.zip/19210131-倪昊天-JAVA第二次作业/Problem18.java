import java.util.Scanner;

public class Problem18 {
    public static void reverse(int a[])
    {
        int i=0,j=a.length-1;
        while(i<j)
        {
            int temp=a[i];
            a[i]=a[j];
            a[j]=temp;
            i++;
            j--;
        }
        return;
    }
    public static void main(String[] args) {
        int[] b={1,2,3,4,5,6,7,8,9,10,12,134,4,61,2,4,12,19,20,28};
        System.out.print("数组转置前：");
        for (int i = 0; i < b.length; i++) {
            System.out.print(b[i]+" ");
        }
        System.out.print("\n数组转置后：");
        reverse(b);
        for (int i = 0; i < b.length; i++) {
            System.out.print(b[i]+" ");
        }
    }
}
