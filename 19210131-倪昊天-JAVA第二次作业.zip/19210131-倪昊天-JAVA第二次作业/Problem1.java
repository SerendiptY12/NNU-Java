
import java.util.Scanner;

public class Problem1 {
    public static int getValue(int i,int j,int k)
    {
       int sum=0;
        for (int l = i; l <= k; l+=j) {
            sum+=l;
            System.out.print(l+"+");
        }
        System.out.print("\b"+"=");
        return sum;
    }
    public static void main(String[] args) 
    {
        Scanner input = new Scanner(System.in);
        int a=input.nextInt();
        int b=input.nextInt();
        int c=input.nextInt();
        System.out.println(getValue(a,b,c));
    }

}
