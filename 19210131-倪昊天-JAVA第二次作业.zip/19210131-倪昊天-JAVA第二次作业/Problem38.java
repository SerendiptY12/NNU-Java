import java.util.Scanner;

/*

第3题  学校里有一个水房，水房里一共装有  m  个龙头可供同学们打开水，每个龙头每秒钟的供水量相等，均为 1。
现在有 n 名同学准备接水，他们的初始接水顺序已经确定。将这些同学按接水顺序从 1 到 n 编号，i 号同学的接水量为 wi。接水开始时，1 到 m 号同学各占一个水龙头，并同时打开水龙头接水。当其中某名同学  j  完成其接水量要求 wj 后，下一名排队等候接水的同学  k 马上接替 j 同学的位置开始接水。这个换人的过程是瞬间完成的，且没有任何水的浪费。亦即，j 同学第 x 秒结束时完成接水，则 k 同学第 x+1 秒立刻开始接水。若当前接水人数 n’不足 m，则只有 n’个龙头供水，其他 m - n’个龙头关闭。
现在给出 n 名同学的接水量，按照上述接水规则，问所有同学都接完水需要多少秒。

输入要求：
请输入两个整数：2 个整数 n 和 m，用一个空格隔开，分别表示接水人数和龙头个数。
如：5 3

再请输入n个整数：n 个整数 w1、w2、…、wn，每两个整数之间用一个空格隔开，wi 表示 i 号同学的接水量。
如：4 4 1 2 1
输出界面：
输出只有一行，1 个整数，表示接水所需的总时间。
如:4

再如：
请输入两个整数：8 4

再请输入8个整数：23 71 87 32 70 93 80 76

输出界面：
163

 */
public class Problem38 {
    public static void main(String[] args) {
        System.out.println("请输入两个整数：");
        Scanner in=new Scanner(System.in);
        int n=in.nextInt();
        int m=in.nextInt();
        int []q=new int[m],w=new int[n];
        System.out.println("再输入"+n+"个整数：");
        for (int i = 0; i < n; i++) {
            w[i]=in.nextInt();
        }
        for(int i=0;i<n;i++)
        {
            int t=0;
            for (int j = 0; j < m; j++) {
                if(q[j]<q[t])
                    t=j;
            }
            q[t]+=w[i];
        }
        int res=0;
        for (int i = 0; i < m; i++) {
            if(res<q[i])
                res=q[i];
        }
        System.out.println(res);
    }
}
