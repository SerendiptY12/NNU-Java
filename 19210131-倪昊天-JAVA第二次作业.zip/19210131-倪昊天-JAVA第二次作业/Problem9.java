import java.util.Scanner;

public class Problem9 {
    public static void CompleteNumber(int i,int j)
    {
        System.out.printf("%d~%d之间的所有的完全数\n",i,j);
        for (int k = i; k <= j ; k++) {
            int ans=0;
            for (int l = 1; l < k ; l++) {
                if (k%l==0)
                    ans+=l;
            }
            if (ans==k)
                System.out.print(k+" ");
        }
    }
    
    public static void main(String[] args) {
        Scanner in=new Scanner(System.in);
        System.out.println("请输入两个正整数：");
        int i=in.nextInt();
        int j=in.nextInt();
        CompleteNumber(i,j);
    }
}
