import java.util.Scanner;

public class Problem15 {
    public static int getValue(int n,int k)
    {
        int count=0;
        while(n>0)
        {
            count++;
            int temp=n%10;
            if(count==k)
            {
                return temp;
            }
            n/=10;
        }
        return -1;
    }
    public static void main(String[] args) {
        Scanner in=new Scanner(System.in);
        int n=0,k=0;
        System.out.print("请输入两个正整数：");
        n=in.nextInt();
        k=in.nextInt();
        int c=getValue(n,k);
        System.out.println(c);
    }
}
