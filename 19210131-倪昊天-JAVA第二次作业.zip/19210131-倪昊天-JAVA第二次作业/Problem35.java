import java.util.Scanner;

/**
 * 第4题 （递归选做题）：使用递归实现如下的功能：
 计算一个自然数，有多少种加表示法。（请使用递归来实现，不要直接使用数学公式一下子计算出来）
 如：自然数5，有：
 5
 4+1
 3+2
 3+1+1
 2+2+1
 2+1+1+1
 1+1+1+1+1
 共七种表示方法。
 程序设计要求：
 1）设计一个递归方法，完成：对给定的参数n(如: 5),在该方法内部，通过递归的方式，计算该数有几种加表示法，并返回该数。
 算法提示：到了这一题，你应该对递归练习得较有心得了。该题的递归算法，请你分析与思考。
 2）在public  static void main(String[] args)方法中，通过Scanner类读入一个整数值，如：5  ，然后通过调用1)定义的递归方法，向这个方法传入刚读入的值进去，在屏幕上按格式输出该方法返回的值。
 输入：
 请输入一个正整数： 5
 输出：
 整数5有7种加表示法`

 */
public class Problem35 {
    static int []t = new int[1024];
    static int count = 0;

    public static int Split(int n,int m)
    {
        t[0] = Integer.MAX_VALUE;
        int i,j,rest;
        for(i=n;i>=1;i--)
        {
            if(i<=t[m-1])
            {
                t[m] = i;

                rest = n - i;
                if(rest==0)
                {
                    count++;
                }
                else
                {
                    Split(rest,m+1);
                }
                t[m]=0;
            }
        }
        return count;
    }
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int n = input.nextInt();
        System.out.println(Split(n,1));
    }
}
