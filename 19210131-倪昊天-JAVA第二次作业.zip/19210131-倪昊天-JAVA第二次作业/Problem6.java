import java.util.Scanner;

public class Problem6 {
    public static double GetValue(int n){
        double ans = 0;
        int j=1;
        for (int i = 1; i <= n ; i++) {
            ans+=(double) j/i;
            j=-j;
        }
        return ans;
    }
    public static void main(String[] args) {
        Scanner in=new Scanner(System.in);
        System.out.print("请输入一个正整数值:");
        int n=in.nextInt();
        System.out.println("和="+GetValue(n));
    }
}
