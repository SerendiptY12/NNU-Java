import java.util.Scanner;

public class Problem3 {
    public static boolean is_Prime(int a)
    {
        boolean flag=true;
        for (int i = 2; i*i <= a ; i++) {
            if (a%i==0) {
                flag=false;
                break;
            }
        }
        if (a==1)
            flag=false;
        return flag;
    }
    public static void main(String[] args) 
    {
        Scanner in=new Scanner(System.in);
        int x;
        x=in.nextInt();
        boolean f;
        f=is_Prime(x);
        if (f==true)
            System.out.println("是质数");
        else
            System.out.println("不是质数");

    }
}
