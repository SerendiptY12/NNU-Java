import java.util.Scanner;

/**
 * 第5题 有n种不同大小的数字ai；每一种数字各有mi个，判断能否从这些数字之中选出若干种数字，使得它们的和正好为K。
 * 要求：
 * 1<=n<=100
 * 1<=ai,mi<=100000
 * 1<=K<=100000
 * 输入界面：
 * 请输入n值：3
 * 请输入各个ai的值：3  5  8
 * 请输入各个mi的值：3  2  2
 * 请输入K值：17
 *
 * 输出界面：
 * 可以组成。方法：3*3+8=17
 */
public class Problem40 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("请输入n值：");
        int n=in.nextInt();
        System.out.print("请输入各个ai的值：");
        int a[]=new int[n];
        for(int i=0;i<n;i++)
            a[i]=in.nextInt();
        System.out.print("请输入各个mi的值：");
        int m[]=new int[n];
        for(int i=0;i<n;i++)
            m[i]=in.nextInt();
        System.out.print("请输入K值：");
        int K=in.nextInt();
        int[] select =new int[n*20];
        int count=he(K,a,m,n-1, select,0);
        if(count!=-1)
        {
            System.out.print("可以组成。方法："+ select[count-1]);
            for(int i=count-2;i>=0;i--)
                System.out.print("+"+ select[i]);
            System.out.println("="+K);
        }
        else
            System.out.println("不可以组成。");
    }

    public static int he(int K,int a[],int m[],int ii,int select[],int count)
    {
        if(K<0)
            return -1;
        if(K==0)
        {
            return count;
        }
        if(ii<0)
            return -1;
        if(ii==0&&m[ii]==0)
            return -1;
        if(m[ii]!=0)
        {
            m[ii]--;
            select[count]=a[ii];
            int cc=he(K-a[ii],a,m,ii,select,count+1);
            if(cc!=-1)
                return cc;
            m[ii]++;
        }
        return he(K,a,m,ii-1,select,count);
}
}
