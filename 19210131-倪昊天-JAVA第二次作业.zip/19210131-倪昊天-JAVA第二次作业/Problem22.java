import java.util.Scanner;

public class Problem22 {
    public static void main(String[] args) {
        Scanner in=new Scanner(System.in);
        System.out.print("请输入一个字符串：");
        String str=in.nextLine();
        int[] count = new int[125];
        for(int i=0;i<125;i++)
            count[i]=0;
        for(int i=0;i<str.length();i++)
            count[(int)str.charAt(i)]++;
        for(int i=0;i<125;i++)
            if(count[i]!=0)
                System.out.println("字符"+(char)i+"出现"+count[i]+"次");
    }
}
