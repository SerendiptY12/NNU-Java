import java.util.Scanner;

public class Problem7 {
    public static int Fib(int n)
    {
        if (n==0)
            return 0;
        else if (n==1)
            return 1;
        else
            return Fib(n-1)+Fib(n-2);
    }
    public static void main(String[] args) {
        Scanner in=new Scanner(System.in);
        System.out.print("请输入一个整数值：");
        int n=in.nextInt();
        System.out.println("F"+n+"的值是:"+Fib(n));

    }
}
