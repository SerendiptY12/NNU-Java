/**
 *
 第26题：设计一个JAVA程序，完成：从键盘上输入一个字符串(句子)。统计它当中的每一个英文单词出现的次数（单词大小写不区分）。如：若输入串是“Twinkle  twinkle  little star ，little  little  star”，则统计结果是：（按单词出现的次数从大到小排序输出，若次数相同，则按单词的字典次序从小到大排序）
 little出现3次；
 twinkle出现2次；
 star出现1次；
 说明：英文单词的含义就是：全部由英文字母组成的串
 输入界面：
 请输入一个字符串：Twinkle  twinkle  little star ，little  little  star
 输出界面：（按单词出现的次数从大到小排序输出，若次数相同，则按单词的字典次序从小到大排序）
 little出现3次；
 twinkle出现2次；
 star出现1次；

 */

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.Set;

public class Problem27 {

    public static void main(String[] args) {
        String str;
        Scanner input = new Scanner(System.in);
        str = input.nextLine();
        str=str.toLowerCase();//将大写字符转换为小写
        String[] str1 = str.split("\\s+|,");
        HashMap<String, Integer> strHash = new HashMap<String, Integer>();
        Integer in=null;
        for(String s:str1){
            in=strHash.put(s, 1);
            if(in!=null){
                strHash.put(s, in+1);
            }
        }
        HashMap<String, Integer> sort1 = sortHashMap(strHash);
        Iterator sort1lit=sort1.entrySet().iterator();
        while(sort1lit.hasNext())z

        {
            Map.Entry<String, Integer> entry=(Entry<String, Integer>) sort1lit.next();
            System.out.println(entry.getKey()+"出现了"+entry.getValue()+"次");
        }

    }
    //排序参考了网络
    public static HashMap<String,Integer> sortHashMap(HashMap<String,Integer> map){
        //從HashMap中恢復entry集合，得到全部的鍵值對集合
        Set<Map.Entry<String,Integer>> entey = map.entrySet();
        //將Set集合轉為List集合，為了實用工具類的排序方法
        List<Map.Entry<String,Integer>> list = new ArrayList<Map.Entry<String,Integer>>(entey);
        //使用Collections工具類對list進行排序
        Collections.sort(list, new Comparator<Map.Entry<String,Integer>>() {
            @Override
            public int compare(Map.Entry<String,Integer> o1, Map.Entry<String,Integer> o2) {
                //按照age倒敘排列
                return o1.getKey().compareTo(o2.getKey());
            }
        });
        //創建一個HashMap的子類LinkedHashMap集合
        LinkedHashMap<String,Integer> linkedHashMap = new LinkedHashMap<String,Integer>();
        //將list中的數據存入LinkedHashMap中
        for(Map.Entry<String,Integer> entry:list){
            linkedHashMap.put(entry.getKey(),entry.getValue());
        }
        return linkedHashMap;
    }


}
