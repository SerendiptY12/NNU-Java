import java.util.Scanner;

/**
 * 第3题（选做题）：设计一个JAVA程序，完成：有n根棍子，长度分别是L1,L2,…,Ln。想要从中选出三根棍子，组成周长尽可能长的三角形。
 程序设计要求：
 #define  N  10或其它你自己设定的值
 程序中按N进行设计。
 输入界面：（xxx是N定义的值）
 请输入xxx根棍子的长度：……………………
 输出界面：
 最大周长的三角形连长分别是:  xxx   yyy    zzz
 若无法组成三角形，则输出：无法组成三角形


 */
public class Problem34 {
    public static void main(String[] args) {
        int N = 10;
        int i,j,k;
        int []length = new int[10];
        Scanner input = new Scanner(System.in);
        System.out.println("请输入10根棍子的长度");
        for(i=0;i<10;i++)
            length[i] = input.nextInt();
        int count = 0;
        int max=0;
        int maxa=0;
        int maxb=0;
        int maxc=0;
        for(i=0;i<N-2;i++)
        {
            for(j=i+1;j<N-1;j++)
            {
                for(k=j+1;k<N;k++)
                {
                    if(length[i]+length[j]>length[k] && length[i]+length[k]>length[j] && length[j]+length[k]>length[i])
                    {
                        count++;
                        if(length[i]+length[j]+length[k]>max)
                        {
                            max = length[i]+length[j]+length[k];
                            maxa = length[i];
                            maxb = length[j];
                            maxc = length[k];
                        }
                    }
                }
            }
        }
        if(count!=0)
            System.out.println("最大周长的三角形连长分别是:"+ maxa +" "+maxb+" "+maxc);
        else
            System.out.println("无法组成三角形");
    }
}

