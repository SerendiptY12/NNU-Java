import java.util.Scanner;

public class Problem23 {
    public static boolean isPalindrome(String str)
    {
        int i=0,j=str.length()-1;
        while (i<j)
        {
            if(str.charAt(i)!=str.charAt(j))
                return false;
            i++;
            j--;
        }
        return true;
    }

    public static void main(String[] args) {
        Scanner in=new Scanner(System.in);
        System.out.print("请输入一个字符串：");
        String str=in.nextLine();
        if(isPalindrome(str))
            System.out.print("字符串"+str+"是一个回文!");
        else
            System.out.print("字符串"+str+"不是一个回文!");
    }
}
