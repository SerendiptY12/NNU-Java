import java.util.Scanner;

/*
第1题（选做题） ：计算一个自然数，有多少种加表示法。要求输出每一种拆分方式。如：自然数5，有7种拆分方式：
5
4+1
3+2
3+1+1
2+2+1
2+1+1+1
1+1+1+1+1
共七种表示方法。
输入：
请输入一个正整数： 5
输出：
整数5有7种拆分方式。拆分结果如下：
5
4+1
3+2
3+1+1
2+2+1
2+1+1+1
1+1+1+1+1
 */
public class Problem32 {
    static int []t = new int[1024];

    public static void Split(int n,int m)
    {
        t[0] = Integer.MAX_VALUE;
        int i,j,rest;
        for(i=n;i>=1;i--)
        {
            if(i<=t[m-1])
            {
                t[m] = i;

                rest = n - i;
                if(rest==0)
                {
                    for(j=1;j<m;j++)
                    {
                        System.out.print(t[j] + "+");
                    }
                    System.out.println(t[j]);
                }
                else
                {
                    Split(rest,m+1);
                }
                t[m]=0;
            }
        }
    }
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int n = input.nextInt();
        Split(n,1);
    }
}
