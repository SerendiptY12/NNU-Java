import java.util.Scanner;

public class Problem20 {
    public static double getValue(double a[],double  b[])
    {
        double sum=0;
        for (int i = 0; i < a.length; i++) {
            sum+=a[i]*b[i];
        }
        return sum;
    }
    public static void main(String[] args) {
        Scanner in=new Scanner(System.in);
        int N;
        System.out.print("若N 是");
        N=in.nextInt()+1;
        System.out.print("请输入"+N+"个系数(实数)");
        double[] a=new double[N];
        for (int i = 0; i <a.length; i++) {
            a[i]=in.nextDouble();
        }
        System.out.print("请输入变量x的值(实数)：");
       double[] x=new double[N];
        x[0]=1;
        x[1]=in.nextDouble();
        for (int i = 2; i < x.length; i++) {
            x[i]=x[i-1]*x[1];
        }
        System.out.print("P(x)="+getValue(a,x));
    }
}
