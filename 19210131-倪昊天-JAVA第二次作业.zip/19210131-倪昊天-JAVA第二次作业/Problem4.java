import java.util.Scanner;

public class Problem4 {
    public static boolean is_Prime(int a)
    {
        boolean flag=true;
        for (int i = 2; i*i <= a ; i++) {
            if (a%i==0) {
                flag=false;
                break;
            }
        }
        if (a==1)
            flag=false;
        return flag;
    }
    public static void print(int a,int b,int c){
        int count=0;
        for (int i = a; i <= b ; i++) {
            if (is_Prime(i)){
                System.out.print(i+" ");
                count++;
            }
            if (count>=c)
            {
                System.out.println();
                count=0;
            }
        }
    }
    public static void main(String[] args) {
        Scanner in=new Scanner(System.in);
        int i,j,k;
        i=in.nextInt();
        j=in.nextInt();
        k=in.nextInt();
        print(i,j,k);

    }
}
