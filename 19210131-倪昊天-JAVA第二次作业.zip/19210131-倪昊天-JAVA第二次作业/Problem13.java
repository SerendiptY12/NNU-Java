import java.util.Scanner;

public class Problem13 {
    public static int reverseValue(int x)
    {
        int xx=0;
        while(x>0)
        {
            xx=xx*10+x%10;
            x/=10;
        }
        return xx;
    }

    public static void main(String[] args) {
        Scanner in=new Scanner(System.in);
        System.out.print("请输入一个正整数值:");
        int a;
        a=in.nextInt();
        System.out.println("输出：");
        System.out.println(reverseValue(a));

    }
}
