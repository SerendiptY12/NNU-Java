import java.util.Scanner;

/*
第2题 ：使用递归实现如下的方法：gcd(a,b)表示整数a和b的最大公约数
gcd(a,b)=gcd(b,a%b)  当b<>0时
gcd(a,b)=a           当b=0时
程序设计要求：
1）设计实现递归方法，完成gcd(a,b)的功能。
2）在public  static void main(String[] args)方法中，通过Scanner类读入两个整数值，如：12  8，然后通过调用1)定义的递归方法，向这个方法传入刚读入的两个值进去，按指定格式在屏幕上输出结果。
输入：
请输入两个正整数： 12  8
输出：
最大公约数是：4
 */
public class Problem29 {
    public static int gcd(int a,int b)
    {
        if (b==0)
            return a;
        else
            return gcd(b,a%b);
    }
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("请输入两个正整数：");
        int a = in.nextInt();
        int b = in.nextInt();
        System.out.println("最大公约数是："+gcd(a,b));
    }
}
