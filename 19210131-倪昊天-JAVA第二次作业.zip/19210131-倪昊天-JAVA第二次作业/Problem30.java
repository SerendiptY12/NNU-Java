import java.util.Scanner;

/*
第3题 ：使用递归实现如下的方法：著名的“Ackman”方法。m和n都是整数
Ack(0,n)=n+1                  当n>=0时
Ack(m,0)=Ack(m-1,1)           当m>=1时
Acm(m,n)=Ack(m-1,Ack(m,n-1))  当m和n都>=1时

程序设计要求：
1）设计实现递归方法，完成Acm(m,n)的功能。
2）在public  static void main(String[] args)方法中，通过Scanner类读入一个整数值，如：12  ，然后通过调用1)定义的递归方法，向这个方法传入刚读入的两个值进去，按指定格式在屏幕上输出结果。
输入：
请输入两个正整数： 1 1
输出：
Acm(1，1)=……
 */
public class Problem30 {
    public static int ack(int m,int n)
    {
        if(m==0&&n>=0)
            return n+1;
        if(m>=1&&n==0)
            return ack(m-1,1);
        else
            return ack(m-1,ack(m,n-1));

    }
    public static void main(String[] args) {
        int m,n;
        System.out.print("请输入两个正整数：");
        Scanner in = new Scanner(System.in);
        m = in.nextInt();
        n = in.nextInt();
        System.out.print("Acm("+m+","+n+")"+"=");
        System.out.println(ack(m,n));
    }

}
