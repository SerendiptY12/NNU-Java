import java.util.Scanner;

// * 第1题   今盒子里有n个小球，A、B两人轮流从盒中取球，每个人都可以看到另一个人取了多少个，也可以看到盒中还剩下多少个，并且两人都很聪明，不会做出错误的判断。
// 我们约定：
// 每个人从盒子中取出的球的数目必须是：1，3，7或者8个。
// 轮到某一方取球时不能弃权！
// A先取球，然后双方交替取球，直到取完。
// 被迫拿到最后一个球的一方为负方（输方）
// 请编程确定出在双方都不判断失误的情况下，对于特定的初始球数，A是否能赢？
// 输入：
// 初始球数=１
// 输出：
// A输
// 再如：
// 输入：
// 初始球数=2
// 输出：
// A赢
//
// 再如：
// 输入：
// 初始球数= 18
// 输出：
// A输
public class Problem36 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int n = input.nextInt();
        int []dp = new int[n+1];
        dp[0] = 1;
        dp[1] = 0;
        int i;
        for(i=1;i<=n;i++)
        {
            int a1 = 1;
            int a2 = 1;
            int a3 = 1;
            int a4 = 1;
            if(i>1)
                a1 = dp[i-1];
            if(i>3)
                a2 = dp[i-3];
            if(i>7)
                a3 = dp[i-7];
            if(i>8)
                a4 = dp[i-8];
            dp[i] = a1&a2&a3&a4;
            dp[i] = 1-dp[i];

        }
        if(dp[n]==1)
            System.out.println("A赢");
        else
            System.out.println("A输");
    }

}
