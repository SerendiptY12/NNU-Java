import java.util.Scanner;

public class Problem17 {
    public static int index(int a[],int val)
    {
        for (int i = 0; i <a.length; i++) {
            if(a[i]==val)
                return i;
        }
        return -1;
    }
    public static void main(String[] args) {
        Scanner in=new Scanner(System.in);
        System.out.print("请输入要寻找的数值：");
        int value=0;
        value=in.nextInt();
        int[] b = new int[20] ;
        for (int i = 0; i < b.length; i++) {
            b[i]=i+1;
        }
        System.out.print("数组内容是:");
        for (int i = 0; i < b.length; i++) {
            System.out.print(b[i]+" ");
        }
        System.out.print("\n"+"该数值在中的下标是：");
        if(index(b,value)==-1)
            System.out.print("在数组中找不到该数值。");
        else
            System.out.print(index(b,value));
    }
}
