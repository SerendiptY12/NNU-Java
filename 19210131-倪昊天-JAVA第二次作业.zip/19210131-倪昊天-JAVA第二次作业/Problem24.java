import java.util.Scanner;
/*
设计一个JAVA程序，完成：字符的排列（排列组合是许多算法的基础）。
如：输入一个字符串"abcd"，再输入一个整数： 2,则输出从4个字符中取2个的字符的排列。
输入界面：
请输入一个字符串:abcd
请输入一个整数：2
输出界面：
取出2个字符的全部排列是：
ab
ac
ad
ba
bc
bd
ca
cb
cd
da
db
dc
 */
public class Problem24 {
    public static void print(int jl[],char org[],char tmp[],int length,int cur) {
        if (cur == length) {//边界条件
            int i;
            for (i = 0; i < length; i++)
                System.out.print(tmp[i]);
            System.out.println();
            return;
        }
        for (int i = 0; i < org.length; i++) {
            if (jl[i] == 0)
                continue;
            tmp[cur++] = org[i];
            jl[i] = 0;
            print(jl, org, tmp, length, cur);
            jl[i] = 1;//恢复现场
            cur--;//dfs 恢复现场
        }
    }
        public static void main(String[] args) {
        Scanner in=new Scanner(System.in);
        System.out.print("请输入一个字符串:");
        String str=in.nextLine();
        char[]org = str.toCharArray();
        char[]tmp = new char[org.length];
        System.out.print("请输入一个整数：");
        int k=in.nextInt();
        int[]jl=new int[org.length];
        int i;
        for(i=0;i<jl.length;i++) {
            jl[i]=1;
        }
        System.out.println("取出2个字符的全部排列是：");
        print(jl,org,tmp,k,0);
    }
}
