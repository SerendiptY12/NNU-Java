import java.util.Scanner;

public class Problem12 {
    public static int sumSquare(int x)
    {
        int ans=0;
        while(x>0)
        {
            int xx=x%10;
            ans+=xx*xx;
            x/=10;
        }
        return ans;
    }
    public static void main(String[] args) {
        Scanner in=new Scanner(System.in);
        System.out.print("请输入一个正整数的值：");
        int num=in.nextInt();
        System.out.print("各位数字的平方和=");
        System.out.println(sumSquare(num));
    }
}
