import java.util.Scanner;

/**
 * 第2题   输入三个正整数A、B和N（1<=N<=300），求A/B的值，要求小数点后精确到N位。
 如：A=1,B=1997,N=25 ，则输出结果：0.0005007511266900350525788
 又如：A=19997  B=197  N=15则输出结果：101.507614213197969
 输入：
 请输入三个正整数（A、B、N值）：19997   197   15
 输出：
 101.507614213197969

 */
public class Problem37 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int A = input.nextInt();
        int B = input.nextInt();
        int N = input.nextInt();
        int m = A/B;
        String result = "";
        result += "" + m+".";
        int count=0;
        A*=10;
        while(count<N)
        {

            int tmp;
            tmp = A / B;
            if(tmp==0)
            {
                A *=10;
                count++;
                result += "" + tmp;
            }
            else
            {
                count++;
                A = A-B*tmp;
                A *= 10;
                result += ""+tmp;
            }
        }
        System.out.println(result);
    }
}
