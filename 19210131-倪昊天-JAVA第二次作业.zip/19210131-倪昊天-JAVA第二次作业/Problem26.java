import java.util.Arrays;
import java.util.Scanner;
/**
 *
 第25题：设计一个JAVA程序，完成：对多个字符串按字典次序进行从小到大排序。
 如：若输入三个字符串：
 Xyz123
 Abc32
 abc
 Abc132
 则排序结果：
 Abc132
 Abc32
 Xyz123
 abc

 程序设计要求：
 输入界面：
 请输入xxx个字符串：
 Xyz123
 Abc32
 abc
 Abc132

 输出界面：
 按字典次序进行从小到大排序结果如下：
 Abc132
 Abc32
 Xyz123
 abc

*/
 public class Problem26 {
    public static void main(String[] args) {
        Scanner in=new Scanner(System.in);
        int n=in.nextInt();
        String[] str=new String[n];
        System.out.println("请输入"+n+"个字符串：");
        in.nextLine();
        for (int i = 0; i < n; i++) {
            str[i]=in.nextLine();
        }
        Arrays.sort(str);
        System.out.println("按字典次序进行从小到大排序结果如下：");
        for (int i = 0; i < n; i++) {
            System.out.println(str[i]);
        }
    }
}
