import java.util.Scanner;

public class Problem21 {
    public static boolean isNull(int b[])
    {
        int i;
        for(i=0;i<b.length;i++)
        {
            if(b[i]==1)
                return false;
        }
        return true;
    }
    public static int findMax(int a[],int b[])
    {
        int i = 0;
        int j;
        for(j=0;j<b.length;j++)
            if(b[j]!=0)
                break;
        int max = a[j];
        while(i<a.length)
        {
            if(max<a[i] && b[i]!=0)
                max=a[i];
            i++;
        }
        for(i=0;i<b.length;i++)
        {
            if(a[i]==max)
                b[i]=0;
        }
        return max;
    }
    public static void main(String[] args) {
        int N;
        Scanner input = new Scanner(System.in);
        System.out.print("若N 是");
        N = input.nextInt();
        int i;
        int[] a = new int[N];
        System.out.println("请输入"+ N +"个正整数：");
        for(i=0;i<N;i++)
            a[i] = input.nextInt();
        int[] b = new int[N];
        for(i=0;i<N;i++)
            b[i] = 1;
        int[] index = new int[N];
        int count = 0;
        while(!isNull(b))
        {
            int max = findMax(a,b);
            System.out.print(max+"\t"+"出现");
            for(i=0;i<a.length;i++)
                if(a[i]==max)
                {
                    index[count++]=i;
                }
            System.out.print(count+"次  ");
            System.out.print("位置在 ");
            for(i=0;i<count;i++)
                System.out.print(index[i]+" ");
            System.out.println();
            count=0;
        }


    }
}
