import java.util.Scanner;

public class Problem5 {
    public static boolean is_Prime(int a)
    {
        boolean flag=true;
        if (a<=2)
            return false;
        for (int i = 2; i*i <= a ; i++) {
            if (a%i==0) {
                flag=false;
                break;
            }
        }
        return flag;
    }
    public static void print_n(int n,int k){
        int count=0;
        for (int i = 2; count < n ; i++) {
            if (is_Prime(i))
            {
                System.out.print(i+" ");
                count++;
                if (count%k==0)
                {
                    System.out.println();
                }
            }
        }

    }
    public static void main(String[] args)
    {
        Scanner in= new Scanner(System.in);
        int n,k;
        n=in.nextInt();
        k=in.nextInt();
        print_n(n,k);
    }
}
