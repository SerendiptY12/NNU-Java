import java.util.Scanner;
import java.util.Stack;
public class Problem25 {

    public static Stack<Character> stack = new Stack<Character>();
    public static void main(String[] args) {
        System.out.print("请输入一个字符串");
        Scanner in = new Scanner(System.in);
        String str = in.nextLine();
        System.out.print("请输入一个整数：");
        int n;
        n = in.nextInt();
        System.out.println("取出"+n+"个字符的全部组合是：");
        char[]data = str.toCharArray();
        assemble(data,n,0,0);
    }
    private static void assemble(char[] data, int target, int has, int cur) {
        if (has == target) {
            char tmp = stack.pop();
            System.out.print(stack.peek());
            stack.add(tmp);
            System.out.print(stack.peek());
            System.out.println();
            return;
        }
        for (int i = cur; i < data.length; i++) {
            if (!stack.contains(data[i])) {
                stack.add(data[i]);
                assemble(data, target, has + 1, i);
                stack.pop();
            }
        }
    }
}