import java.util.Scanner;

public class Problem14 {
    public static boolean isTG_num(int num)
    {
        boolean flag=true;
        int xx=num*num;
        while(num>0)
        {
            if(num%10!=xx%10)
            {
                flag=false;
                break;
            }
            num/=10;
            xx/=10;
        }
        return flag;
    }
    public static void print(int a,int b) {
        int cnt=0;
        for (int i = a; i <= b; i++){
            if(isTG_num(i))
            {
                System.out.print(i+" ");
                cnt++;
            }
            if (cnt==10)
            {
                System.out.println();
                cnt= 0;
            }

        }
    }
    public static void main(String[] args) {
        Scanner in=new Scanner(System.in);
        int a=0,b=0;
        System.out.print("请输入两个正整数：");
        a=in.nextInt();
        b=in.nextInt();
        System.out.println(a+"~"+b+"之内的同构数有:");
        print(a,b);
    }
}
