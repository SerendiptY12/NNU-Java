import java.util.Scanner;

/**
 * 第2题（选做题）：设计一个JAVA程序，完成：大数相乘。用字符串表示两个大数：如"123487651234776856769097372"，另一个大数是"4738647676323671564356281516767"，要求完成这两个套数的相相乘，结果是一个新的字符串。
 输入界面：
 请输入两个大数：
 123487651234776856769097372
 4738647676323671564356281516767
 输出界面：
 相乘结果是:
 ……………………………

 */
public class Problem33 {
    public static String multiply(String str1,String str2){
        int[] n1 = new int[str1.length()];
        int[] n2 = new int[str2.length()];
        int[] result = new int[str1.length() + str2.length()];
        for (int i = 0;i < str1.length(); i++){
            n1[i] = Integer.parseInt(str1.substring(i,i+1));
        }
        for (int i = 0;i < str2.length(); i++){
            n2[i] = Integer.parseInt(str2.substring(i,i+1));
        }
        for (int a = 0;a < str1.length(); a++){
            for (int b = 0;b < str2.length(); b++){
                result[a+b] += n1[a]*n2[b];
            }
        }
        int temp;
        for (int k = result.length-1; k > 0; k--){
            temp=result[k]/10;
            result[k-1] += temp;
            result[k] = result[k]%10;
        }
        String resultstr = "";
        for (int i = 0; i < result.length-1; i++){
            resultstr += "" + result[i];
        }

        return resultstr;
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("请输入两个大数：");
        String str1 = input.next();
        String str2 = input.next();
        System.out.println("相乘结果是：");
        System.out.println(multiply(str1,str2));
    }
}
