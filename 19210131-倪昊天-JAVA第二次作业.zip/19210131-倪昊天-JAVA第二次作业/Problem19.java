import java.util.Scanner;

public class Problem19 {
    public static boolean isNull(boolean flag[])
    {
        int i;
        for(i=0;i<flag.length;i++)
        {
            if(flag[i]==false)
                return false;
        }
        return true;
    }
    public static void main(String[] args) {
        Scanner in=new Scanner(System.in);
        int[] b=new int[11];
        int k=0,j=0;
        System.out.print("请输入11个整数值:");
        for (int i = 0; i < b.length; i++) {
            b[i]=in.nextInt();
        }
        System.out.print("请输入步长：:");
        k=in.nextInt();
        System.out.print("数组内容是：");
        for (int i = 0; i < b.length; i++) {
            System.out.print(b[i]+" ");
        }
        System.out.println();
        System.out.print("按步长输出的序列是：");
        boolean[] flag=new boolean[11];//记录是否走过
        while(!isNull(flag))
        {
            int kk=k;
            while (true)
            {
                j %= b.length;
                if (flag[j]==false)//如果没有走过则步过
                    kk--;
                if (kk == 0) {
                    System.out.print(b[j] + " ");
                    flag[j] = true;
                    break;
                }
                j++;
            }

        }
    }
}
