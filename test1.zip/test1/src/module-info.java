/**
 * 
 */
/**
 * @author user
 *
 */
module test1 {
}