package test1;

public class problem16 {
	public static void main(String[] args) {
		// TODO 自动生成的方法存根
		for(int i=1;i<18;i++)
		{
			for(int j=2;j<19;j++)
				for(int k=3;k<20;k++)
			       for(int t=4;t<=20;t++)
			       {
			    	   if(i>=j||j>=k||k>=t)
			    		   continue;
			    	   if((double)1/i+(double)1/j+(double)1/k+(double)1/t==1)
			    		   System.out.println(t+","+k+","+j+","+i+",0");
			       }
		}
	}
}
