package test1;

import java.util.Scanner;


public class problem13 {
	public static void main(String[] args) {
		// TODO 自动生成的方法存根
		Scanner input = new Scanner(System.in);
	    int a = input.nextInt();//整型
	    int b = input.nextInt();//整型
	    int c = input.nextInt();//整型
	    for(int i=10;i<100;i++)
	    {
	    	if(i%3==a&&i%5==b&&i%7==c)
	    	{
	    		System.out.println("总人数（最小值）="+i);
	    		return;
	    	}
	    }
	    System.out.println("无解");
	}
}
