package test1;

import java.util.Scanner;

public class problem7 {
	public static void main(String[] args)
	{
		Scanner input = new Scanner(System.in);
        int i = input.nextInt();
        int j = input.nextInt();
        int k = input.nextInt();
        
        int count=0;
        for(;i<=j;i++)
        {
            int m=2;
            while(i%m!=0)
            {
                m++;
            }
            if(i==m)
            {
            	count++;
            	if(count%k==0)
                    System.out.println(i);
            	else 
                    System.out.print(i+" ");
                
            }                   
        }
	}
}

