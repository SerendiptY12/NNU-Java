package test1;

public class problem11 {
	public static void main(String[] args) {
		for(int i=1000;i<10000;i++)
		{
			if(i/1000==i%1000/100&&i%100/10==i%10&&Math.sqrt(i)-(int)Math.sqrt(i)==0)
				System.out.println(i);
		}
	}

}
