package test1;

import java.util.Scanner;


public class problem10 {
	public static void main(String[] args) {
		  Scanner input = new Scanner(System.in);
	      int a = input.nextInt();
	      int b = input.nextInt();
	      while(b!=0)
	      {
	    	if(b!=0)
	    		{int temp=a;
	    		a=b;
	    		b=temp%b;}
	      }
	      System.out.println(a);
	}
}
