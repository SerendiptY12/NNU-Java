package test1;

import java.util.Scanner;

public class problem2 {
	public static void main(String[] args)
	{
		Scanner cin=new Scanner(System.in);
		int n=cin.nextInt();
		int t=cin.nextInt();
		char ch=cin.next().charAt(0);
		//System.out.println();
		for(int i=0;i<n;i++)
		{	
			for(int j=0;j<n-i-1;j++)
				System.out.print(" ");
			for(int j=0;j<i*2+1;j++)
				System.out.print(ch);
			System.out.println();
		}
		for(int i=0;i<t;i++)
			{for(int j=1;j<n;j++)
				System.out.print(" ");
			System.out.print(ch);
			System.out.println();
			}
	}	
}
