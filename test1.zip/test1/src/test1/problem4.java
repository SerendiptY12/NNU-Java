package test1;

import java.util.Scanner;

public class problem4 {
	public static void main(String[] args)
	{
		Scanner cin=new Scanner(System.in);
		int n=cin.nextInt();
		int i=1,sum=0;
		while(i<n)
		{
			System.out.print(i);
			sum+=i;
			i+=2;
			if(i<n)
				System.out.print("+");
		}
		System.out.println("="+sum);
	}
}
