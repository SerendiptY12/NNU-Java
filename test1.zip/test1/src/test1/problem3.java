package test1;

public class problem3 {
	public static void main(String[] args) {
		byte b1=(byte)0xaa;
		byte b2=(byte)0xbb;
		byte b3=(byte)0xcc;
		byte b4=(byte)0xdd;
		int  i = 0;
		i = ((int)b4 << 24) | ((int)b3 << 16) | ((int)b2 << 8) | (int)b1;
		System.out.println(i);
	}
}
