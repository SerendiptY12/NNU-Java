package test1;

import java.util.Scanner;

public class problem5 {
	public static void main(String[] args)
	{
		Scanner cin=new Scanner(System.in);
		int i=cin.nextInt();
		int j=cin.nextInt();
		int sum=0;
		while(i<=j)
		{
			System.out.print(i);
			sum+=i;
			i++;
			if(i<=j)
				System.out.print("+");
		}
		System.out.println("="+sum);
	}
}
