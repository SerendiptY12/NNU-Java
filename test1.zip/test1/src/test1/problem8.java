package test1;
import java.util.Scanner;
public class problem8 {
	public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int n = input.nextInt();//����
        int k = input.nextInt();//����
        int count=0,i=2;
        while(count<n)
        {
            int j=2;
            while(i%j!=0)
            {
                j++;
            }
            if(i==j)
            {
            	count++;
            	if(count%k==0)
                    System.out.println(i);
            	else 
                    System.out.print(i+" ");
                
            }
            
            i++;
        }
}
}
