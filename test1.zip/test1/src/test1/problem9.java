package test1;

import java.text.DecimalFormat;
import java.util.Scanner;

public class problem9 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
	    int n = input.nextInt();//����
	    DecimalFormat df=new DecimalFormat("0.000000");
		double sum=0.0;
	    for(int i=1;i<=n;i++)
		{
			if(i%2==1)
				sum+=(double)1/i;
			else
				sum-=(double)1/i;
		}
		System.out.println("��="+df.format(sum));
		
	}
}
