package test1;

public class problem14 {
	public static void main(String[] args) {
		// TODO 自动生成的方法存根
		for(int i=123;i<=329;i++)
		{	
			int j=i*2;
			int k=i*3;
			int sum=0;
			int xnt=1;
			int x=i;
			while(x>0)
			{
				int m=x%10;
				sum+=m;
				xnt*=m;
				x/=10;
			}
			
			
			x=j;
			while(x>0)
			{
				int m=x%10;
				sum+=m;
				xnt*=m;
				x/=10;
			}
			x=k;
			while(x>0)
			{
				int m=x%10;
				sum+=m;
				xnt*=m;
				x/=10;
			}
			if(sum==45&&xnt==362880)
				System.out.println(i+","+j+","+k);
		}
	}
}
