package test1;

import java.util.Scanner;

public class problem12 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
	    int n = input.nextInt();
	    int num=0;
	    for(int i=1;i<=n;i++)
	    {
	    	int k=i;
	    	int sum=1;
	    	while(k>1)
	    	{
	    		sum*=(k%1000000);
	    		k--;
	    	}
	    	num+=sum%1000000;
	    	num%=1000000;
	    }
	    System.out.println(num);
	}
}
