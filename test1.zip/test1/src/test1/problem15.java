package test1;

import java.util.Scanner;

public class problem15 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
	    int n = input.nextInt();//整型
	    int i=1;
	    while((1+i)*i/2<n)
	    {
	    	i++;
	    }
	    int t=n-(i-1)*i/2;
	    if(i%2==0)
	    	System.out.println(t+"/"+(i-t+1));
	    else
	    	System.out.println((i-t+1)+"/"+t);
	}
}
