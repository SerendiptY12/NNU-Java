
public class Elem {
	 public double res;
	    public String info;
	    public Elem(double r,String i){
	        res = r; 
	        info = i; 
	    }
}
