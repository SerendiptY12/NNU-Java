package test3;
import java.util.Scanner;

public class Problem1 {
	public double real;
	public double imaginary;
	
	public Problem1()
	{
		this.real=0;
		this.imaginary=0;
	}
	
	public Problem1(double real,double imaginary)
	{
		this.real=real;
		this.imaginary=imaginary;
	}
	
	public Problem1 add(Problem1 a,Problem1 b)
	{
		return new Problem1(a.real+b.real,a.imaginary+b.imaginary);
	}
	
	public Problem1 sub(Problem1 a,Problem1 b)
	{
		return new Problem1(a.real-b.real,a.imaginary-b.imaginary);
	}
	
	public Problem1 multi(Problem1 a,Problem1 b)
	{
		return new Problem1((a.real*b.real-a.imaginary*b.imaginary),(a.real*b.imaginary+b.real*a.imaginary));
	}
	
	public Problem1 div(Problem1 a,Problem1 b)
	{
		return new Problem1((a.real*b.real+a.imaginary*b.imaginary)/(b.real*b.real+b.imaginary*b.imaginary),(-a.real*b.imaginary+a.imaginary*b.real)/(b.real*b.real+b.imaginary*b.imaginary));
	}
	
	public void print()
	{
		if(this.imaginary<0)
		{
			System.out.println(this.real+""+this.imaginary+"i");
		}
		else
		{
			System.out.println(this.real+"+"+this.imaginary+"i");
		}
	}
	
	public static void main(String args[])
	{
		Problem1 a=new Problem1(2,6);
		a.print();
		Problem1 b=new Problem1(3,4);
		b.print();
		Problem1 c=new Problem1(0,0);
		System.out.println("加法：");
		c=c.add(a, b);
		c.print();
		System.out.println("减法：");
		c=c.sub(a, b);
		c.print();
		System.out.println("乘法：");
		c=c.multi(a, b);
		c.print();
		System.out.println("除法：");
		c=c.div(a, b);
		c.print();
	}	

}
